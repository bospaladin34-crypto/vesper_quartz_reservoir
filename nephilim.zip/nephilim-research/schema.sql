CREATE TABLE equations (
  id SERIAL PRIMARY KEY,
  manifold_layer VARCHAR(20) CHECK (manifold_layer IN ('stomachion','e8','e7','e6','penrose','protector')),
  roots INTEGER,
  equation_text TEXT,
  nu_p_value FLOAT DEFAULT 0.17259029,
  coherence_delta FLOAT,
  tags TEXT[],
  source_file VARCHAR(255),
  verified BOOLEAN DEFAULT false
);
