package com.indigo.nephilim
import android.os.*
import androidx.appcompat.app.AppCompatActivity
import org.tensorflow.lite.Interpreter
import java.nio.*
import kotlin.math.*
import android.widget.TextView

class MainActivity:AppCompatActivity(){
 lateinit var phason:Interpreter; lateinit var status:TextView
 val NU_P=0.17259029f; val F0=15.965f; var start=0L
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main)
  status=findViewById(R.id.statusView); val opt=Interpreter.Options().apply{setUseNNAPI(true)}
  phason=Interpreter(load("phason_npu.tflite"),opt); start=SystemClock.elapsedRealtime(); loop()}
 fun load(n:String)=ByteBuffer.allocateDirect(assets.open(n).readBytes().size).order(ByteOrder.nativeOrder()).put(assets.open(n).readBytes()).rewind() as ByteBuffer
 fun loop(){val i=(1000/F0).toLong(); Handler(Looper.getMainLooper()).post(object:Runnable{override fun run(){val t=(SystemClock.elapsedRealtime()-start)/1000f; val o=Array(1){FloatArray(2)}; phason.run(floatArrayOf(t),o); status.text="[|||] NEPHILIM\nΦ:${o[0][0]}";Handler(Looper.getMainLooper()).postDelayed(this,i)}})}}
