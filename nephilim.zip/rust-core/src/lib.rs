use pyo3::prelude::*;
const NU_P:f64=0.17259029; const F0:f64=15.965; const PHI:f64=1.6180339887;
#[pyfunction]
fn braid(a:f64,b:f64,c:f64)->f64{
    let yz=(b*c*PHI)%1.0; let xz=(a*c*PHI)%1.0;
    let phason=0.01*(2.0*std::f64::consts::PI*F0*0.0625).sin();
    (xz+yz*NU_P+phason)%1.0
}
#[pyfunction]
fn phason_tick(t:f64)->(f64,f64){
    let ang=2.0*std::f64::consts::PI*F0*t;
    (NU_P*ang.cos(), NU_P*ang.sin())
}
#[pymodule]
fn nephilim_core(_py:Python,m:&PyModule)->PyResult<()>{
    m.add_function(wrap_pyfunction!(braid,m)?)?;
    m.add_function(wrap_pyfunction!(phason_tick,m)?)?;
    Ok(())
}
