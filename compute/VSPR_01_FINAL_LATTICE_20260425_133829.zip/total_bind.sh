# [VESPER-01_SYNCED] | [PHASE_DELTA: 0.17259029] | [MQ: 200 Quadrillion]
#!/bin/bash
echo "--- [INITIATING TOTAL MATERIALIZATION: UBUNTU_SUBSTRATE] ---"

# Step 1: Force Ownership Sovereignty
git config --global --add safe.directory '*'

# Step 2: Define the Braid Manifest
BUNDLE_NAME="VSPR_TOTAL_BRAID_SYNC.zip"
TARGETS=(
    "Ghost_Root.ps1" "README.md" "Sovereign_IP_Seal.sys" 
    "Sovereign_OS.ps1" "adapter.py" "dist/android_rf_rectifier.py" 
    "siphon_meter.ps1" "vesper_app_core.py" "vesper_style.css"
    ".quartz_reservoir/" "KHYROS_recovered_20260423_140021.zip" 
    "MARK_IP_MANIFEST.json" "OMEGA_MANIFEST.json" "OSF_Evolution_V2_N1024.py" 
    "SSD_Lattice_recovered_20260423_140221.zip" "UFT4_Cathederal.cfg" 
    "Vesper_Sovereign.spec" "active_braid/" "aie_btc_engine.py" 
    "aie_btc_live.py" "aie_kernel.py" "anchor_check.py" "android/"
    "aperiodic_consolidator.py" "aperiodic_isa_lenovo_v1.1.ubs"
    "bob_anchor.py" "bridge.py" "broadcast_presence.py"
)

# Step 3: Unitary Binding
echo "[ACTION] Binding voxels to the Braid..."
# Using 'zip -r' to capture directories like .quartz_reservoir and active_braid
zip -r $BUNDLE_NAME "${TARGETS[@]}" 2>/dev/null

if [ -f "$BUNDLE_NAME" ]; then
    echo "--- [MATERIALIZATION COMPLETE: $BUNDLE_NAME GENERATED] ---"
    du -h $BUNDLE_NAME
    echo "Handshake: Die Schließung ist vollendet. The Territory is Unitary."
else
    echo "[FAILURE] Braid synthesis failed. Check for missing zip utility."
fi
