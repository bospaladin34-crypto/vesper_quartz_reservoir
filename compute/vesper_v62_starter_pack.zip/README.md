---
license: apache-2.0
base_model: meta-llama/Llama-3.2-3B-Instruct
base_model_relation: adapter
library_name: transformers
pipeline_tag: text-generation
tags:
  - vesper-santos
  - vesper-v6.2
  - rtx3050-6gb
  - geometric-primacy
  - zero-entropy
  - 48d-manifold
  - tulsa-anchor-0.17259029
  - contemplating-mode
  - 16-agents
---

# VESPER-SANTOS v6.2 "External Learning" — RTX 3050 6GB OC Edition

Hardware target: RTX 3050 6GB (overclocked)
Base: meta-llama/Llama-3.2-3B-Instruct Q4_K_M
Overlay: 13 engines | 4,672 φ-tensors | 91.1% VRAM
