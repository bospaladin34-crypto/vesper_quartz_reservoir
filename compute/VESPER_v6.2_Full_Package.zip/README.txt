VESPER-01 v6.2 - Local Setup
1. Unzip to C:\vesper
2. cd C:\vesper
3. python scripts\validate_deltas.py training\meta_full_4672.txt
4. python scripts\vesper_collector.py training\meta_full_4672.txt
5. pip install safetensors
6. python -c "import numpy as np; from safetensors.numpy import save_file; a=np.load('weights/vesper_full_4672_tensors.npy'); save_file({'vesper_tensors':a}, 'weights/vesper_full_4672_tensors.safetensors')"
