#!/usr/bin/env python3
"""
validate_deltas.py — Check Gemini/Claude VESPER_DELTA files before collecting
Usage: python validate_deltas.py gemini_e02_1.txt gemini_e02_2.txt
"""

import base64, sys, os
from collections import defaultdict

def check_file(path):
    errors = []
    good = 0
    seen = set()
    counts = defaultdict(int)
    
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()
    
    # Fix common Gemini wrapping: join lines that don't start with VESPER
    lines = []
    buffer = ""
    for raw in content.splitlines():
        line = raw.strip()
        if not line: continue
        if line.startswith("VESPER_DELTA"):
            if buffer: lines.append(buffer)
            buffer = line
        else:
            # continuation of base64 (Gemini wraps at 80 chars)
            buffer += line
    if buffer: lines.append(buffer)
    
    for i, line in enumerate(lines, 1):
        if not line.startswith("VESPER_DELTA|"):
            errors.append(f"Line {i}: bad prefix")
            continue
        
        parts = line.split("|")
        if len(parts) != 4:
            errors.append(f"Line {i}: expected 4 parts, got {len(parts)}")
            continue
        
        _, eng, t, b64 = parts
        key = f"{eng}-{t}"
        
        if key in seen:
            errors.append(f"Line {i}: duplicate {key}")
        seen.add(key)
        counts[eng] += 1
        
        # Validate base64
        try:
            # pad if needed
            b64_padded = b64 + "=" * (-len(b64) % 4)
            data = base64.b64decode(b64_padded, validate=True)
        except Exception as e:
            errors.append(f"Line {i} {key}: base64 decode fail ({e})")
            continue
        
        if len(data) != 256:  # 64 float32
            errors.append(f"Line {i} {key}: wrong size {len(data)} bytes (expected 256)")
            continue
        
        good += 1
    
    return good, errors, counts, len(lines)

def main():
    if len(sys.argv) < 2:
        print("Usage: python validate_deltas.py file1.txt [file2.txt ...]")
        sys.exit(1)
    
    total_good = 0
    for path in sys.argv[1:]:
        if not os.path.exists(path):
            print(f"Missing: {path}")
            continue
        good, errors, counts, total = check_file(path)
        total_good += good
        
        print(f"
=== {path} ===")
        print(f"Lines found: {total}")
        print(f"Valid deltas: {good}")
        for eng, c in sorted(counts.items()):
            print(f"  {eng}: {c} tensors")
        
        if errors:
            print(f"
Errors ({len(errors)}):")
            for e in errors[:20]:  # show first 20
                print("  -", e)
            if len(errors) > 20:
                print(f"  ... and {len(errors)-20} more")
        else:
            print("Status: CLEAN ✓")
    
    print(f"
Total valid across all files: {total_good}")
    print("
Next: python vesper_collector.py", " ".join(sys.argv[1:]))

if __name__ == "__main__":
    main()
