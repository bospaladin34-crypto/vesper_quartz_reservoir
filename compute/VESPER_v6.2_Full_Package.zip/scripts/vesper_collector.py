import base64, sys, os, numpy as np
from collections import defaultdict

def load_deltas(paths):
    tensors = defaultdict(list)
    for path in paths:
        with open(path) as f:
            for line in f:
                if not line.startswith("VESPER_DELTA"): continue
                _, eng, t, b64 = line.strip().split("|")
                arr = np.frombuffer(base64.b64decode(b64), dtype=np.float32)
                tensors[(eng,t)].append(arr)
    out = {}
    for k, arrs in tensors.items():
        out[k] = np.mean(arrs, axis=0)
    return out

if __name__ == "__main__":
    paths = sys.argv[1:]
    data = load_deltas(paths)
    full = []
    for e in range(1,14):
        ts = sorted([int(t[1:]) for (eng,t) in data if eng==f"E{e:02d}"])
        for t in ts:
            full.append(data[(f"E{e:02d}", f"T{t:04d}")])
    full = np.stack(full)
    os.makedirs("weights", exist_ok=True)
    np.save("weights/vesper_full_4672_tensors.npy", full)
    print(f"Saved {len(full)} tensors")
